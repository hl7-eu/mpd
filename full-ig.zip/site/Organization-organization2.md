# organization2 - HL7 Europe Medication Prescription and Dispense v0.1.0-ci-build

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **organization2**

## Example Organization: organization2

**identifier**: Ph-1234

**name**: Su-Bin Pharmacy B



## Resource Content

```json
{
  "resourceType" : "Organization",
  "id" : "organization2",
  "identifier" : [
    {
      "value" : "Ph-1234"
    }
  ],
  "name" : "Su-Bin Pharmacy B"
}

```
