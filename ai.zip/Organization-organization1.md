# organization1 - HL7 Europe Medication Prescription and Dispense v0.1.0-ci-build

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **organization1**

## Example Organization: organization1

**identifier**: A12567

**name**: Dr Ärztin Private Practice



## Resource Content

```json
{
  "resourceType" : "Organization",
  "id" : "organization1",
  "identifier" : [
    {
      "value" : "A12567"
    }
  ],
  "name" : "Dr Ärztin Private Practice"
}

```
